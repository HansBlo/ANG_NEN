import { Routes } from '@angular/router';
import {TableComponent} from './table-component/table-component';

export const routes: Routes = [
  {
    path: '',
    component: TableComponent,
  }
];
