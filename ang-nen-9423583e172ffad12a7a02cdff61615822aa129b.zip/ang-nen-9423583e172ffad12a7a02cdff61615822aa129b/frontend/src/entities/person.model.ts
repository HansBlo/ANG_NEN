export class Person {
  id?:number;
  vorname?:string;
  nachname?:string;
  alter?:string;
  email?:string;
  stadt?:string;
  beruf?:string;
  datum?:string;
}
